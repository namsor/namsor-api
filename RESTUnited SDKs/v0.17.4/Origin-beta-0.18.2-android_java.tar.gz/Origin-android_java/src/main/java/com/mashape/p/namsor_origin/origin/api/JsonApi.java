package com.mashape.p.namsor_origin.origin.api;

import com.mashape.p.namsor_origin.client.ApiException;
import com.mashape.p.namsor_origin.client.ApiInvoker;
import com.mashape.p.namsor_origin.origin.model.OriginList;
import com.mashape.p.namsor_origin.origin.model.NamesList;
import com.mashape.p.namsor_origin.origin.model.Origin;
import java.util.*;
import java.io.File;

public class JsonApi {
  String basePath = "https://namsor-origin.p.mashape.com";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public void addHeader(String key, String value) {
    getInvoker().addDefaultHeader(key, value);
  }

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  //error info- code: 400 reason: "Bad request" model: <none>
  //error info- code: 401 reason: "Unauthorized " model: <none>
  //error info- code: 403 reason: "Forbidden " model: <none>
  //error info- code: 404 reason: "Resource not found" model: <none>
  //error info- code: 502 reason: "Bad gateway" model: <none>
  //error info- code: 503 reason: "Service Unavailable" model: <none>
  public OriginList originList (String XMashapeKey, NamesList body) throws ApiException {
    //HACK for post body
    Object postBody = body;

    // verify required params are set
    if(XMashapeKey == null || body == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/json/originList".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    headerParams.put("X-Mashape-Key", XMashapeKey);
    // HACK: set contentType based on consume
    //String contentType = "application/json";

    String[] contentTypes = {
      "application/json"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      //boolean hasFields = false;
      //FormDataMultiPart mp = new FormDataMultiPart();
      ////if(hasFields)
      //  postBody = mp;
    }
    else {
      }

    //HACK END

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, body, headerParams, formParams, contentType);
      if(response != null){
        return (OriginList) ApiInvoker.deserialize(response, "", OriginList.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
        return null;
      }
      else {
        throw ex;
      }
    }
  }
  //error info- code: 400 reason: "Bad request" model: <none>
  //error info- code: 401 reason: "Unauthorized " model: <none>
  //error info- code: 403 reason: "Forbidden " model: <none>
  //error info- code: 404 reason: "Resource not found" model: <none>
  //error info- code: 502 reason: "Bad gateway" model: <none>
  //error info- code: 503 reason: "Service Unavailable" model: <none>
  public Origin origin (String XMashapeKey, String firstname, String lastname) throws ApiException {
    //HACK for post body
    Object postBody = null;

    // verify required params are set
    if(XMashapeKey == null || firstname == null || lastname == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/json/origin/{firstname}/{lastname}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "firstname" + "\\}", apiInvoker.escapeString(firstname.toString())).replaceAll("\\{" + "lastname" + "\\}", apiInvoker.escapeString(lastname.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    headerParams.put("X-Mashape-Key", XMashapeKey);
    // HACK: set contentType based on consume
    //String contentType = "application/json";

    String[] contentTypes = {
      "application/x-www-form-urlencoded"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      //boolean hasFields = false;
      //FormDataMultiPart mp = new FormDataMultiPart();
      ////if(hasFields)
      //  postBody = mp;
    }
    else {
      }

    //HACK END

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams, contentType);
      if(response != null){
        return (Origin) ApiInvoker.deserialize(response, "", Origin.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
        return null;
      }
      else {
        throw ex;
      }
    }
  }
  }

