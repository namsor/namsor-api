package com.mashape.p.namsor_origin.origin.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.*;
public class NamesList {
  /* Names */
  @JsonProperty("names")
  private List<Names> names = new ArrayList<Names>();
  public List<Names> getNames() {
    return names;
  }
  public void setNames(List<Names> names) {
    this.names = names;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class NamesList {\n");
    sb.append("  names: ").append(names).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

