#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGOriginList : SWGObject

@property(nonatomic) NSArray* names;  /* Names [optional]*/

- (id) names: (NSArray*) names;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

