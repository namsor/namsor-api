#import <Foundation/Foundation.h>
#import "SWGOriginList.h"
#import "SWGNamesList.h"
#import "SWGOrigin.h"



@interface SWGJsonApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGJsonApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

  
 Origin List
 @param XMashapeKey API key or token for authorization
 @param body List of personal names.
 */
-(NSNumber*) origin_listWithCompletionBlock :(NSString*) XMashapeKey 
        body:(SWGNamesList*) body 
        completionHandler: (void (^)(SWGOriginList* output, NSError* error))completionBlock;

/**

  
 Origin
 @param XMashapeKey API key or token for authorization
 @param firstname Firstname
 @param lastname Lastname
 */
-(NSNumber*) originWithCompletionBlock :(NSString*) XMashapeKey 
        firstname:(NSString*) firstname 
        lastname:(NSString*) lastname 
        completionHandler: (void (^)(SWGOrigin* output, NSError* error))completionBlock;

@end
