#import "SWGDate.h"
#import "SWGOrigin.h"

@implementation SWGOrigin

-(id)country: (NSString*) country
    countryAlt: (NSString*) countryAlt
    countryFirstName: (NSString*) countryFirstName
    countryLastName: (NSString*) countryLastName
    countryName: (NSString*) countryName
    region: (NSString*) region
    score: (NSNumber*) score
    scoreFirstName: (NSNumber*) scoreFirstName
    scoreLastName: (NSNumber*) scoreLastName
    script: (NSString*) script
    subRegion: (NSString*) subRegion
    topRegion: (NSString*) topRegion
{
  _country = country;
  _countryAlt = countryAlt;
  _countryFirstName = countryFirstName;
  _countryLastName = countryLastName;
  _countryName = countryName;
  _region = region;
  _score = score;
  _scoreFirstName = scoreFirstName;
  _scoreLastName = scoreLastName;
  _script = script;
  _subRegion = subRegion;
  _topRegion = topRegion;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _country = dict[@"country"]; 
        _countryAlt = dict[@"countryAlt"]; 
        _countryFirstName = dict[@"countryFirstName"]; 
        _countryLastName = dict[@"countryLastName"]; 
        _countryName = dict[@"countryName"]; 
        _region = dict[@"region"]; 
        _score = dict[@"score"]; 
        _scoreFirstName = dict[@"scoreFirstName"]; 
        _scoreLastName = dict[@"scoreLastName"]; 
        _script = dict[@"script"]; 
        _subRegion = dict[@"subRegion"]; 
        _topRegion = dict[@"topRegion"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_country != nil) dict[@"country"] = _country ;
        if(_countryAlt != nil) dict[@"countryAlt"] = _countryAlt ;
        if(_countryFirstName != nil) dict[@"countryFirstName"] = _countryFirstName ;
        if(_countryLastName != nil) dict[@"countryLastName"] = _countryLastName ;
        if(_countryName != nil) dict[@"countryName"] = _countryName ;
        if(_region != nil) dict[@"region"] = _region ;
        if(_score != nil) dict[@"score"] = _score ;
        if(_scoreFirstName != nil) dict[@"scoreFirstName"] = _scoreFirstName ;
        if(_scoreLastName != nil) dict[@"scoreLastName"] = _scoreLastName ;
        if(_script != nil) dict[@"script"] = _script ;
        if(_subRegion != nil) dict[@"subRegion"] = _subRegion ;
        if(_topRegion != nil) dict[@"topRegion"] = _topRegion ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

