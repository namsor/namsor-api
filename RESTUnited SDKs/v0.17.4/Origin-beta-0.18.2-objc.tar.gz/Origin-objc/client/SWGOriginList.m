#import "SWGDate.h"
#import "SWGOriginList.h"

@implementation SWGOriginList

-(id)names: (NSArray*) names
{
  _names = names;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        id names_dict = dict[@"names"];
        if([names_dict isKindOfClass:[NSArray class]]) {

            NSMutableArray * objs = [[NSMutableArray alloc] initWithCapacity:[(NSArray*)names_dict count]];

            if([(NSArray*)names_dict count] > 0) {
                for (NSDictionary* dict in (NSArray*)names_dict) {
                    NSArray* d = [[NSArray alloc] initWithValues:dict];
                    [objs addObject:d];
                }
                
                _names = [[NSArray alloc] initWithArray:objs];
            }
            else {
                _names = [[NSArray alloc] init];
            }
        }
        else {
            _names = [[NSArray alloc] init];
        }
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_names != nil){
        if([_names isKindOfClass:[NSArray class]]){
            NSMutableArray * array = [[NSMutableArray alloc] init];
            for( NSArray *names in (NSArray*)_names) {
                [array addObject:[(SWGObject*)names asDictionary]];
            }
            dict[@"names"] = array;
        }
        else if(_names && [_names isKindOfClass:[SWGDate class]]) {
            NSString * dateString = [(SWGDate*)_names toString];
            if(dateString){
                dict[@"names"] = dateString;
            }
        }
        else {
        if(_names != nil) dict[@"names"] = [(SWGObject*)_names asDictionary];
        }
    }
    NSDictionary* output = [dict copy];
    return output;
}

@end

