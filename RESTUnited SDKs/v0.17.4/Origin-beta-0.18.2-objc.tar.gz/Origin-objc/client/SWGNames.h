#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGNames : SWGObject

@property(nonatomic) NSString* country;  /* Country [optional]*/

@property(nonatomic) NSString* countryAlt;  /* Countryalt [optional]*/

@property(nonatomic) NSString* countryFirstName;  /* Countryfirstname [optional]*/

@property(nonatomic) NSString* countryLastName;  /* Countrylastname [optional]*/

@property(nonatomic) NSString* countryName;  /* Countryname [optional]*/

@property(nonatomic) NSString* firstName;  /* Firstname [optional]*/

@property(nonatomic) NSString* _id;  /* ID [optional]*/

@property(nonatomic) NSString* lastName;  /* Lastname [optional]*/

@property(nonatomic) NSString* region;  /* Region [optional]*/

@property(nonatomic) NSNumber* score;  /* Score [optional]*/

@property(nonatomic) NSNumber* scoreFirstName;  /* Scorefirstname [optional]*/

@property(nonatomic) NSNumber* scoreLastName;  /* Scorelastname [optional]*/

@property(nonatomic) NSString* script;  /* Script [optional]*/

@property(nonatomic) NSString* subRegion;  /* Subregion [optional]*/

@property(nonatomic) NSString* topRegion;  /* Topregion [optional]*/

- (id) country: (NSString*) country
     countryAlt: (NSString*) countryAlt
     countryFirstName: (NSString*) countryFirstName
     countryLastName: (NSString*) countryLastName
     countryName: (NSString*) countryName
     firstName: (NSString*) firstName
     _id: (NSString*) _id
     lastName: (NSString*) lastName
     region: (NSString*) region
     score: (NSNumber*) score
     scoreFirstName: (NSNumber*) scoreFirstName
     scoreLastName: (NSNumber*) scoreLastName
     script: (NSString*) script
     subRegion: (NSString*) subRegion
     topRegion: (NSString*) topRegion;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

