package com.mashape.p.namsor_origin.origin.model;

public class Origin {
  /* Country */
  private String country = null;
  /* Countryalt */
  private String countryAlt = null;
  /* Countryfirstname */
  private String countryFirstName = null;
  /* Countrylastname */
  private String countryLastName = null;
  /* Countryname */
  private String countryName = null;
  /* Region */
  private String region = null;
  /* Score */
  private Double score = null;
  /* Scorefirstname */
  private Double scoreFirstName = null;
  /* Scorelastname */
  private Double scoreLastName = null;
  /* Script */
  private String script = null;
  /* Subregion */
  private String subRegion = null;
  /* Topregion */
  private String topRegion = null;
  public String getCountry() {
    return country;
  }
  public void setCountry(String country) {
    this.country = country;
  }

  public String getCountryAlt() {
    return countryAlt;
  }
  public void setCountryAlt(String countryAlt) {
    this.countryAlt = countryAlt;
  }

  public String getCountryFirstName() {
    return countryFirstName;
  }
  public void setCountryFirstName(String countryFirstName) {
    this.countryFirstName = countryFirstName;
  }

  public String getCountryLastName() {
    return countryLastName;
  }
  public void setCountryLastName(String countryLastName) {
    this.countryLastName = countryLastName;
  }

  public String getCountryName() {
    return countryName;
  }
  public void setCountryName(String countryName) {
    this.countryName = countryName;
  }

  public String getRegion() {
    return region;
  }
  public void setRegion(String region) {
    this.region = region;
  }

  public Double getScore() {
    return score;
  }
  public void setScore(Double score) {
    this.score = score;
  }

  public Double getScoreFirstName() {
    return scoreFirstName;
  }
  public void setScoreFirstName(Double scoreFirstName) {
    this.scoreFirstName = scoreFirstName;
  }

  public Double getScoreLastName() {
    return scoreLastName;
  }
  public void setScoreLastName(Double scoreLastName) {
    this.scoreLastName = scoreLastName;
  }

  public String getScript() {
    return script;
  }
  public void setScript(String script) {
    this.script = script;
  }

  public String getSubRegion() {
    return subRegion;
  }
  public void setSubRegion(String subRegion) {
    this.subRegion = subRegion;
  }

  public String getTopRegion() {
    return topRegion;
  }
  public void setTopRegion(String topRegion) {
    this.topRegion = topRegion;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Origin {\n");
    sb.append("  country: ").append(country).append("\n");
    sb.append("  countryAlt: ").append(countryAlt).append("\n");
    sb.append("  countryFirstName: ").append(countryFirstName).append("\n");
    sb.append("  countryLastName: ").append(countryLastName).append("\n");
    sb.append("  countryName: ").append(countryName).append("\n");
    sb.append("  region: ").append(region).append("\n");
    sb.append("  score: ").append(score).append("\n");
    sb.append("  scoreFirstName: ").append(scoreFirstName).append("\n");
    sb.append("  scoreLastName: ").append(scoreLastName).append("\n");
    sb.append("  script: ").append(script).append("\n");
    sb.append("  subRegion: ").append(subRegion).append("\n");
    sb.append("  topRegion: ").append(topRegion).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

