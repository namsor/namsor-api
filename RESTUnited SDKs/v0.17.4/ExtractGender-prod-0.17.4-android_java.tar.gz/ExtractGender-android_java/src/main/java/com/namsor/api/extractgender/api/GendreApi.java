package com.namsor.api.extractgender.api;

import com.namsor.api.client.ApiException;
import com.namsor.api.client.ApiInvoker;
import com.namsor.api.extractgender.model.Genderize;
import java.util.*;
import java.io.File;

public class GendreApi {
  String basePath = "http://api.namsor.com/onomastics/api/json";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public void addHeader(String key, String value) {
    getInvoker().addDefaultHeader(key, value);
  }

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  //error info- code: 503 reason: "Service Unavailable" model: <none>
  //error info- code: 502 reason: "Bad gateway" model: <none>
  //error info- code: 404 reason: "Resource not found" model: <none>
  //error info- code: 403 reason: "Forbidden " model: <none>
  //error info- code: 401 reason: "Unauthorized " model: <none>
  //error info- code: 400 reason: "Bad request" model: <none>
  public Genderize genderize (String firstName, String lastName, String countryIso2, String XClientVersion) throws ApiException {
    //HACK for post body
    Object postBody = null;

    // verify required params are set
    if(firstName == null || lastName == null || countryIso2 == null || XClientVersion == null ) {
       throw new ApiException(400, "missing required params");
    }
    // create path and map variables
    String path = "/gendre/{firstName}/{lastName}/{countryIso2}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "firstName" + "\\}", apiInvoker.escapeString(firstName.toString())).replaceAll("\\{" + "lastName" + "\\}", apiInvoker.escapeString(lastName.toString())).replaceAll("\\{" + "countryIso2" + "\\}", apiInvoker.escapeString(countryIso2.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    headerParams.put("X-Client-Version", XClientVersion);
    // HACK: set contentType based on consume
    //String contentType = "application/json";

    String[] contentTypes = {
      "application/x-www-form-urlencoded"};

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      //boolean hasFields = false;
      //FormDataMultiPart mp = new FormDataMultiPart();
      ////if(hasFields)
      //  postBody = mp;
    }
    else {
      }

    //HACK END

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams, contentType);
      if(response != null){
        return (Genderize) ApiInvoker.deserialize(response, "", Genderize.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      if(ex.getCode() == 404) {
        return null;
      }
      else {
        throw ex;
      }
    }
  }
  }

