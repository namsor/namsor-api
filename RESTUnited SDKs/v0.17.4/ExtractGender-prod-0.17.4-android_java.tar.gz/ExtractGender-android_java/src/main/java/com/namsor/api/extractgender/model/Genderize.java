package com.namsor.api.extractgender.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Genderize {
  /* Firstname */
  @JsonProperty("firstName")
  private String firstName = null;
  /* Gender */
  @JsonProperty("gender")
  private String gender = null;
  /* ID */
  @JsonProperty("id")
  private String id = null;
  /* Lastname */
  @JsonProperty("lastName")
  private String lastName = null;
  /* Scale */
  @JsonProperty("scale")
  private Double scale = null;
  public String getFirstName() {
    return firstName;
  }
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getGender() {
    return gender;
  }
  public void setGender(String gender) {
    this.gender = gender;
  }

  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getLastName() {
    return lastName;
  }
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public Double getScale() {
    return scale;
  }
  public void setScale(Double scale) {
    this.scale = scale;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Genderize {\n");
    sb.append("  firstName: ").append(firstName).append("\n");
    sb.append("  gender: ").append(gender).append("\n");
    sb.append("  id: ").append(id).append("\n");
    sb.append("  lastName: ").append(lastName).append("\n");
    sb.append("  scale: ").append(scale).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

