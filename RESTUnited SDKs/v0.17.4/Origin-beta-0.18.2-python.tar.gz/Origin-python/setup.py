from setuptools import setup, find_packages

setup(
    name="Origin",
    version="0.18.2",
    description="Python wrapper for Origin",
    author="RESTUntied",
    author_email="feedback@restunited.com",
    url="https://restunited.com/releases/362298905252070923/wrappers",
    packages=find_packages(),
    license="Apache License 2.0",
)
