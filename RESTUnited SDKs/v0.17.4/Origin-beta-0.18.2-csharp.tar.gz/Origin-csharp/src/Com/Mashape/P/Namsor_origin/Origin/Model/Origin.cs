using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Com.Mashape.P.Namsor_origin.Origin.Model {
  public class Origin {
    /* Country */
    public string country { get; set; }

    /* Countryalt */
    public string countryAlt { get; set; }

    /* Countryfirstname */
    public string countryFirstName { get; set; }

    /* Countrylastname */
    public string countryLastName { get; set; }

    /* Countryname */
    public string countryName { get; set; }

    /* Region */
    public string region { get; set; }

    /* Score */
    public double? score { get; set; }

    /* Scorefirstname */
    public double? scoreFirstName { get; set; }

    /* Scorelastname */
    public double? scoreLastName { get; set; }

    /* Script */
    public string script { get; set; }

    /* Subregion */
    public string subRegion { get; set; }

    /* Topregion */
    public string topRegion { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Origin {\n");
      sb.Append("  country: ").Append(country).Append("\n");
      sb.Append("  countryAlt: ").Append(countryAlt).Append("\n");
      sb.Append("  countryFirstName: ").Append(countryFirstName).Append("\n");
      sb.Append("  countryLastName: ").Append(countryLastName).Append("\n");
      sb.Append("  countryName: ").Append(countryName).Append("\n");
      sb.Append("  region: ").Append(region).Append("\n");
      sb.Append("  score: ").Append(score).Append("\n");
      sb.Append("  scoreFirstName: ").Append(scoreFirstName).Append("\n");
      sb.Append("  scoreLastName: ").Append(scoreLastName).Append("\n");
      sb.Append("  script: ").Append(script).Append("\n");
      sb.Append("  subRegion: ").Append(subRegion).Append("\n");
      sb.Append("  topRegion: ").Append(topRegion).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
