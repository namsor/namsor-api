  using System;
  using System.Collections.Generic;
  using Com.Mashape.P.Namsor_origin.Origin;
  using Com.Mashape.P.Namsor_origin.Origin.Model;
  namespace Com.Mashape.P.Namsor_origin.Origin.Api {
    public class JsonApi {
      string basePath;
      private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

      public JsonApi(String basePath = "https://namsor-origin.p.mashape.com")
      {
        this.basePath = basePath;
      }

      public ApiInvoker getInvoker() {
        return apiInvoker;
      }

      // Sets the endpoint base url for the services being accessed
      public void setBasePath(string basePath) {
        this.basePath = basePath;
      }

      // Gets the endpoint base url for the services being accessed
      public String getBasePath() {
        return basePath;
      }

      /// <summary>
      ///   Origin List
      /// </summary>
      /// <param name="_X_Mashape_Key">API key or token for authorization</param>
      /// <param name="body">List of personal names.</param>
      /// <returns></returns>
      public OriginList OriginList (string _X_Mashape_Key, NamesList body) {
        // create path and map variables
        var path = "/json/originList".Replace("{format}","json");

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (_X_Mashape_Key == null || body == null ) {
           throw new ApiException(400, "missing required params");
        }
        headerParams.Add("X-Mashape-Key", _X_Mashape_Key);
        try {
          if (typeof(OriginList) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as OriginList;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, body, headerParams, formParams);
            if(response != null){
               return (OriginList) ApiInvoker.deserialize(response, typeof(OriginList));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      /// <summary>
      ///   Origin
      /// </summary>
      /// <param name="_X_Mashape_Key">API key or token for authorization</param>
      /// <param name="firstname">Firstname</param>
      /// <param name="lastname">Lastname</param>
      /// <returns></returns>
      public Origin Origin (string _X_Mashape_Key, string firstname, string lastname) {
        // create path and map variables
        var path = "/json/origin/{firstname}/{lastname}".Replace("{format}","json").Replace("{" + "firstname" + "}", apiInvoker.escapeString(firstname.ToString())).Replace("{" + "lastname" + "}", apiInvoker.escapeString(lastname.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (_X_Mashape_Key == null || firstname == null || lastname == null ) {
           throw new ApiException(400, "missing required params");
        }
        headerParams.Add("X-Mashape-Key", _X_Mashape_Key);
        try {
          if (typeof(Origin) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as Origin;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (Origin) ApiInvoker.deserialize(response, typeof(Origin));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      }
    }

