using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Com.Mashape.P.Namsor_origin.Origin.Model {
  public class OriginList {
    /* Names */
    public List<Names> names { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class OriginList {\n");
      sb.Append("  names: ").Append(names).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
