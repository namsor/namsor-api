#import "SWGGendreApi.h"
#import "SWGFile.h"
#import "SWGApiClient.h"
#import "SWGGenderize.h"




@implementation SWGGendreApi
static NSString * basePath = @"http://api.namsor.com/onomastics/api/json";

+(SWGGendreApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key {
    static SWGGendreApi* singletonAPI = nil;

    if (singletonAPI == nil) {
        singletonAPI = [[SWGGendreApi alloc] init];
        [singletonAPI addHeader:headerValue forKey:key];
    }
    return singletonAPI;
}

+(void) setBasePath:(NSString*)path {
    basePath = path;
}

+(NSString*) getBasePath {
    return basePath;
}

-(SWGApiClient*) apiClient {
    return [SWGApiClient sharedClientFromPool:basePath];
}

-(void) addHeader:(NSString*)value forKey:(NSString*)key {
    [[self apiClient] setHeaderValue:value forKey:key];
}

-(id) init {
    self = [super init];
    [self apiClient];
    return self;
}

-(void) setHeaderValue:(NSString*) value
           forKey:(NSString*)key {
    [[self apiClient] setHeaderValue:value forKey:key];
}

-(unsigned long) requestQueueSize {
    return [SWGApiClient requestQueueSize];
}


-(NSNumber*) genderizeWithCompletionBlock:(NSString*) firstName
        lastName:(NSString*) lastName
        countryIso2:(NSString*) countryIso2
        XClientVersion:(NSString*) XClientVersion
        completionHandler: (void (^)(SWGGenderize* output, NSError* error))completionBlock{

    NSMutableString* requestUrl = [NSMutableString stringWithFormat:@"%@/gendre/{firstName}/{lastName}/{countryIso2}", basePath];

    // remove format in URL if needed
    if ([requestUrl rangeOfString:@".{format}"].location != NSNotFound)
        [requestUrl replaceCharactersInRange: [requestUrl rangeOfString:@".{format}"] withString:@".json"];

    [requestUrl replaceCharactersInRange: [requestUrl rangeOfString:[NSString stringWithFormat:@"%@%@%@", @"{", @"firstName", @"}"]] withString: [SWGApiClient escape:firstName]];
    [requestUrl replaceCharactersInRange: [requestUrl rangeOfString:[NSString stringWithFormat:@"%@%@%@", @"{", @"lastName", @"}"]] withString: [SWGApiClient escape:lastName]];
    [requestUrl replaceCharactersInRange: [requestUrl rangeOfString:[NSString stringWithFormat:@"%@%@%@", @"{", @"countryIso2", @"}"]] withString: [SWGApiClient escape:countryIso2]];
    NSString* requestContentType = @"application/json";
    NSString* responseContentType = @"application/json";

        NSMutableDictionary* queryParams = [[NSMutableDictionary alloc] init];
    NSMutableDictionary* headerParams = [[NSMutableDictionary alloc] init];
    if(XClientVersion != nil)
        headerParams[@"X-Client-Version"] = XClientVersion;
    id bodyDictionary = nil;
        if(firstName == nil) {
        // error
    }
    if(lastName == nil) {
        // error
    }
    if(countryIso2 == nil) {
        // error
    }
    if(XClientVersion == nil) {
        // error
    }
    SWGApiClient* client = [SWGApiClient sharedClientFromPool:basePath];

    return [client dictionary:requestUrl 
                              method:@"GET" 
                         queryParams:queryParams 
                                body:bodyDictionary 
                        headerParams:headerParams
                  requestContentType:requestContentType
                 responseContentType:responseContentType
                     completionBlock:^(NSDictionary *data, NSError *error) {
                        if (error) {
                            completionBlock(nil, error);return;
                        }
                        SWGGenderize *result = nil;
                        if (data) {
                            result = [[SWGGenderize alloc]initWithValues: data];
                        }
                        completionBlock(result , nil);}];
    

}



@end
