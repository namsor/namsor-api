#import <Foundation/Foundation.h>
#import "SWGGenderize.h"



@interface SWGGendreApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGGendreApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

  
 Genderize
 @param firstName Firstname
 @param lastName Lastname
 @param countryIso2 Countryiso2
 @param XClientVersion Library Version (Client)
 */
-(NSNumber*) genderizeWithCompletionBlock :(NSString*) firstName 
        lastName:(NSString*) lastName 
        countryIso2:(NSString*) countryIso2 
        XClientVersion:(NSString*) XClientVersion 
        completionHandler: (void (^)(SWGGenderize* output, NSError* error))completionBlock;

@end
