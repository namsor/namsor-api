#import "SWGDate.h"
#import "SWGGenderize.h"

@implementation SWGGenderize

-(id)firstName: (NSString*) firstName
    gender: (NSString*) gender
    _id: (NSString*) _id
    lastName: (NSString*) lastName
    scale: (NSNumber*) scale
{
  _firstName = firstName;
  _gender = gender;
  __id = _id;
  _lastName = lastName;
  _scale = scale;
  return self;
}

-(id) initWithValues:(NSDictionary*)dict
{
    self = [super init];
    if(self) {
        _firstName = dict[@"firstName"]; 
        _gender = dict[@"gender"]; 
        __id = dict[@"id"]; 
        _lastName = dict[@"lastName"]; 
        _scale = dict[@"scale"]; 
        

    }
    return self;
}

-(NSDictionary*) asDictionary {
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if(_firstName != nil) dict[@"firstName"] = _firstName ;
        if(_gender != nil) dict[@"gender"] = _gender ;
        if(__id != nil) dict[@"id"] = __id ;
        if(_lastName != nil) dict[@"lastName"] = _lastName ;
        if(_scale != nil) dict[@"scale"] = _scale ;
        NSDictionary* output = [dict copy];
    return output;
}

@end

