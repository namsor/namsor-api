#import <Foundation/Foundation.h>
#import "SWGObject.h"


@interface SWGGenderize : SWGObject

@property(nonatomic) NSString* firstName;  /* Firstname [optional]*/

@property(nonatomic) NSString* gender;  /* Gender [optional]*/

@property(nonatomic) NSString* _id;  /* ID [optional]*/

@property(nonatomic) NSString* lastName;  /* Lastname [optional]*/

@property(nonatomic) NSNumber* scale;  /* Scale [optional]*/

- (id) firstName: (NSString*) firstName
     gender: (NSString*) gender
     _id: (NSString*) _id
     lastName: (NSString*) lastName
     scale: (NSNumber*) scale;

- (id) initWithValues: (NSDictionary*)dict;
- (NSDictionary*) asDictionary;


@end

