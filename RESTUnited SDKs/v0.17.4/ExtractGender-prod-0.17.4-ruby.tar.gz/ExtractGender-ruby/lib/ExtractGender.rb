# Create the base module
module ExtractGender 

# Swagger common files
require 'ExtractGender/monkey.rb'
require 'ExtractGender/swagger.rb'
require 'ExtractGender/swagger/configuration.rb'
require 'ExtractGender/swagger/request.rb'
require 'ExtractGender/swagger/response.rb'
require 'ExtractGender/swagger/version.rb'


# Models
require 'ExtractGender/models/genderize.rb'


# APIs
require 'ExtractGender/api/gendre_api.rb'


end
