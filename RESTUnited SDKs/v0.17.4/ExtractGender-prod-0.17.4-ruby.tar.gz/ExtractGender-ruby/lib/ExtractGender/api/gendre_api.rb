require "uri"

module ExtractGender
class GendreAPI
  basePath = "http://api.namsor.com/onomastics/api/json"
  # apiInvoker = APIInvoker

  def self.escapeString(string)
    URI.encode(string.to_s)
  end

  def self.genderize (firstName,lastName,countryIso2,_X_Client_Version= "restunited_v0.17.x",opts={})
    query_param_keys = []

    # verify existence of params
    raise "firstName is required" if firstName.nil?
    raise "lastName is required" if lastName.nil?
    raise "countryIso2 is required" if countryIso2.nil?
    raise "_X_Client_Version is required" if _X_Client_Version.nil?
    # set default values and merge with input
    #HACK: use '' for key
    options = {
    :'firstName' => firstName,
      :'lastName' => lastName,
      :'countryIso2' => countryIso2,
      :'X-Client-Version' => _X_Client_Version}.merge(opts)

    #resource path
    path = "/gendre/{firstName}/{lastName}/{countryIso2}".sub('{format}','json').sub('{' + 'firstName' + '}', escapeString(firstName))
    .sub('{' + 'lastName' + '}', escapeString(lastName))
    .sub('{' + 'countryIso2' + '}', escapeString(countryIso2))
    

    
    # pull querystring keys from options
    queryopts = options.select do |key,value|
      query_param_keys.include? key
    end
  
    #HACK: use '' for key
    headers = {}
    headers[:'X-Client-Version'] = _X_Client_Version
    # http header
    headers['Accept'] = 'application/json'
    headers['Content-Type'] = 'application/x-www-form-urlencoded'
    
    post_body = nil
    #HACK: form parameter
    has_fields = false
    form_parameter_hash = {}
    if has_fields
      uri = Addressable::URI.new
      uri.query_values = form_parameter_hash
      post_body = uri.query 
    end

    response = Swagger::Request.new(:GET, path, {:params=>queryopts,:headers=>headers, :body=>post_body }).make.body
    Genderize.new(response)

  end

end
end

