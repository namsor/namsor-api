package com.namsor.api.extract_gender.api

import com.namsor.api.extract_gender.model.Genderize
import com.namsor.api.client.ApiInvoker
import com.namsor.api.client.ApiException

import java.io.File
import java.util.Date

import scala.collection.mutable.HashMap

class GendreApi {
  var basePath: String = "http://api.namsor.com/onomastics/api/json"
  var apiInvoker = ApiInvoker
  
  def addHeader(key: String, value: String) = apiInvoker.defaultHeaders += key -> value 

  def genderize (firstName: String, lastName: String, countryIso2: String, X-Client-Version: String= "restunited_v0.17.x") : Option[Genderize]= {
    // create path and map variables
    val path = "/gendre/{firstName}/{lastName}/{countryIso2}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "firstName" + "\\}",apiInvoker.escape(firstName))

    .replaceAll("\\{" + "lastName" + "\\}",apiInvoker.escape(lastName))

    .replaceAll("\\{" + "countryIso2" + "\\}",apiInvoker.escape(countryIso2))

    

    val contentType = {
      "application/json"}

    // query params
    val queryParams = new HashMap[String, String]
    val headerParams = new HashMap[String, String]

    // verify required params are set
    (List(firstName, lastName, countryIso2, X-Client-Version).filter(_ != null)).size match {
       case 4 => // all required values set
       case _ => throw new Exception("missing required params")
    }
    headerParams += "X-Client-Version" -> X-Client-Version
    try {
      apiInvoker.invokeApi(basePath, path, "GET", queryParams.toMap, None, headerParams.toMap, contentType) match {
        case s: String =>
          Some(ApiInvoker.deserialize(s, "", classOf[Genderize]).asInstanceOf[Genderize])
        case _ => None
      }
    } catch {
      case ex: ApiException if ex.code == 404 => None
      case ex: ApiException => throw ex
    }
  }
  }

