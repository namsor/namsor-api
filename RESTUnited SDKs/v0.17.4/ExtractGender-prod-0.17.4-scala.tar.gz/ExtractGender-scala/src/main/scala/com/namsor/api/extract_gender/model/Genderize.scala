package com.namsor.api.extract_gender.model

case class Genderize (
  /* Firstname */
  firstName: String,
  /* Gender */
  gender: String,
  /* ID */
  id: String,
  /* Lastname */
  lastName: String,
  /* Scale */
  scale: Double)

