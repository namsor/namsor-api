package com.mashape.p.namsor_origin.origin.model

case class Origin (
  /* Country */
  country: String,
  /* Countryalt */
  countryAlt: String,
  /* Countryfirstname */
  countryFirstName: String,
  /* Countrylastname */
  countryLastName: String,
  /* Countryname */
  countryName: String,
  /* Region */
  region: String,
  /* Score */
  score: Double,
  /* Scorefirstname */
  scoreFirstName: Double,
  /* Scorelastname */
  scoreLastName: Double,
  /* Script */
  script: String,
  /* Subregion */
  subRegion: String,
  /* Topregion */
  topRegion: String)

