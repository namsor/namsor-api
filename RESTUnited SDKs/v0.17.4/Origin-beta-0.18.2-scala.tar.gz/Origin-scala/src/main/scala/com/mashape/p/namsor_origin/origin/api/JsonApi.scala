package com.mashape.p.namsor_origin.origin.api

import com.mashape.p.namsor_origin.origin.model.OriginList
import com.mashape.p.namsor_origin.origin.model.NamesList
import com.mashape.p.namsor_origin.origin.model.Origin
import com.mashape.p.namsor_origin.client.ApiInvoker
import com.mashape.p.namsor_origin.client.ApiException

import java.io.File
import java.util.Date

import scala.collection.mutable.HashMap

class JsonApi {
  var basePath: String = "https://namsor-origin.p.mashape.com"
  var apiInvoker = ApiInvoker
  
  def addHeader(key: String, value: String) = apiInvoker.defaultHeaders += key -> value 

  def originList (X-Mashape-Key: String, body: NamesList) : Option[OriginList]= {
    // create path and map variables
    val path = "/json/originList".replaceAll("\\{format\\}","json")

    val contentType = {
      if(body != null && body.isInstanceOf[File] )
        "multipart/form-data"
      else "application/json"
      }

    // query params
    val queryParams = new HashMap[String, String]
    val headerParams = new HashMap[String, String]

    // verify required params are set
    (List(X-Mashape-Key, body).filter(_ != null)).size match {
       case 2 => // all required values set
       case _ => throw new Exception("missing required params")
    }
    headerParams += "X-Mashape-Key" -> X-Mashape-Key
    try {
      apiInvoker.invokeApi(basePath, path, "POST", queryParams.toMap, body, headerParams.toMap, contentType) match {
        case s: String =>
          Some(ApiInvoker.deserialize(s, "", classOf[OriginList]).asInstanceOf[OriginList])
        case _ => None
      }
    } catch {
      case ex: ApiException if ex.code == 404 => None
      case ex: ApiException => throw ex
    }
  }
  def origin (X-Mashape-Key: String, firstname: String= "John", lastname: String= "Smith") : Option[Origin]= {
    // create path and map variables
    val path = "/json/origin/{firstname}/{lastname}".replaceAll("\\{format\\}","json").replaceAll("\\{" + "firstname" + "\\}",apiInvoker.escape(firstname))

    .replaceAll("\\{" + "lastname" + "\\}",apiInvoker.escape(lastname))

    

    val contentType = {
      "application/json"}

    // query params
    val queryParams = new HashMap[String, String]
    val headerParams = new HashMap[String, String]

    // verify required params are set
    (List(X-Mashape-Key, firstname, lastname).filter(_ != null)).size match {
       case 3 => // all required values set
       case _ => throw new Exception("missing required params")
    }
    headerParams += "X-Mashape-Key" -> X-Mashape-Key
    try {
      apiInvoker.invokeApi(basePath, path, "GET", queryParams.toMap, None, headerParams.toMap, contentType) match {
        case s: String =>
          Some(ApiInvoker.deserialize(s, "", classOf[Origin]).asInstanceOf[Origin])
        case _ => None
      }
    } catch {
      case ex: ApiException if ex.code == 404 => None
      case ex: ApiException => throw ex
    }
  }
  }

