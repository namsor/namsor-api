package com.mashape.p.namsor_origin.origin.model

import com.mashape.p.namsor_origin.origin.model.Names
case class NamesList (
  /* Names */
  names: List[Names])

