package com.mashape.p.namsor_origin.origin.model

import com.mashape.p.namsor_origin.origin.model.Names
case class OriginList (
  /* Names */
  names: List[Names])

