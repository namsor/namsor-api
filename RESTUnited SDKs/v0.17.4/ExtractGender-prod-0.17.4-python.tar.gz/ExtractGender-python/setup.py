from setuptools import setup, find_packages

setup(
    name="ExtractGender",
    version="0.17.4",
    description="Python wrapper for Extract Gender",
    author="RESTUntied",
    author_email="feedback@restunited.com",
    url="https://restunited.com/releases/353822053726422518/wrappers",
    packages=find_packages(),
    license="Apache License 2.0",
)
