using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Com.Namsor.Api.ExtractGender.Model {
  public class Genderize {
    /* Firstname */
    public string firstName { get; set; }

    /* Gender */
    public string gender { get; set; }

    /* ID */
    public string id { get; set; }

    /* Lastname */
    public string lastName { get; set; }

    /* Scale */
    public double? scale { get; set; }

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Genderize {\n");
      sb.Append("  firstName: ").Append(firstName).Append("\n");
      sb.Append("  gender: ").Append(gender).Append("\n");
      sb.Append("  id: ").Append(id).Append("\n");
      sb.Append("  lastName: ").Append(lastName).Append("\n");
      sb.Append("  scale: ").Append(scale).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  }
