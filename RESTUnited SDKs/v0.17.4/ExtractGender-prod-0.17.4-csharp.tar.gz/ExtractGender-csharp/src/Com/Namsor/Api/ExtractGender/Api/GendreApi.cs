  using System;
  using System.Collections.Generic;
  using Com.Namsor.Api.ExtractGender;
  using Com.Namsor.Api.ExtractGender.Model;
  namespace Com.Namsor.Api.ExtractGender.Api {
    public class GendreApi {
      string basePath;
      private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

      public GendreApi(String basePath = "http://api.namsor.com/onomastics/api/json")
      {
        this.basePath = basePath;
      }

      public ApiInvoker getInvoker() {
        return apiInvoker;
      }

      // Sets the endpoint base url for the services being accessed
      public void setBasePath(string basePath) {
        this.basePath = basePath;
      }

      // Gets the endpoint base url for the services being accessed
      public String getBasePath() {
        return basePath;
      }

      /// <summary>
      ///   Genderize
      /// </summary>
      /// <param name="firstName">Firstname</param>
      /// <param name="lastName">Lastname</param>
      /// <param name="countryIso2">Countryiso2</param>
      /// <param name="_X_Client_Version">Library Version (Client)</param>
      /// <returns></returns>
      public Genderize Genderize (string firstName, string lastName, string countryIso2, string _X_Client_Version) {
        // create path and map variables
        var path = "/gendre/{firstName}/{lastName}/{countryIso2}".Replace("{format}","json").Replace("{" + "firstName" + "}", apiInvoker.escapeString(firstName.ToString())).Replace("{" + "lastName" + "}", apiInvoker.escapeString(lastName.ToString())).Replace("{" + "countryIso2" + "}", apiInvoker.escapeString(countryIso2.ToString()));

        // query params
        var queryParams = new Dictionary<String, String>();
        var headerParams = new Dictionary<String, String>();
        var formParams = new Dictionary<String, object>();

        // verify required params are set
        if (firstName == null || lastName == null || countryIso2 == null || _X_Client_Version == null ) {
           throw new ApiException(400, "missing required params");
        }
        headerParams.Add("X-Client-Version", _X_Client_Version);
        try {
          if (typeof(Genderize) == typeof(byte[])) {
            var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            return ((object)response) as Genderize;
          } else {
            var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
            if(response != null){
               return (Genderize) ApiInvoker.deserialize(response, typeof(Genderize));
            }
            else {
              return null;
            }
          }
        } catch (ApiException ex) {
          if(ex.ErrorCode == 404) {
          	return null;
          }
          else {
            throw ex;
          }
        }
      }
      }
    }

