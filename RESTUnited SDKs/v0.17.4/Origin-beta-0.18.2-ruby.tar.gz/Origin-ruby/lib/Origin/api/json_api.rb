require "uri"

module Origin
class JsonAPI
  basePath = "https://namsor-origin.p.mashape.com"
  # apiInvoker = APIInvoker

  def self.escapeString(string)
    URI.encode(string.to_s)
  end

  def self.origin_list (_X_Mashape_Key,body,opts={})
    query_param_keys = []

    # verify existence of params
    raise "_X_Mashape_Key is required" if _X_Mashape_Key.nil?
    raise "body is required" if body.nil?
    # set default values and merge with input
    #HACK: use '' for key
    options = {
    :'X-Mashape-Key' => _X_Mashape_Key,
      :'body' => body}.merge(opts)

    #resource path
    path = "/json/originList".sub('{format}','json')

    
    # pull querystring keys from options
    queryopts = options.select do |key,value|
      query_param_keys.include? key
    end
  
    #HACK: use '' for key
    headers = {}
    headers[:'X-Mashape-Key'] = _X_Mashape_Key
    # http header
    headers['Accept'] = 'application/json'
    headers['Content-Type'] = 'application/json'
    
    post_body = nil
    if body != nil
      if body.is_a?(Array)
        array = Array.new
        body.each do |item|
          if item.respond_to?("to_body".to_sym)
            array.push item.to_body
          else
            array.push item
          end
        end
        post_body = array

      else 
        if body.respond_to?("to_body".to_sym)
	        post_body = body.to_body
	      else
	        post_body = body
	      end
      end
    end
    #HACK: form parameter
    has_fields = false
    form_parameter_hash = {}
    if has_fields
      uri = Addressable::URI.new
      uri.query_values = form_parameter_hash
      post_body = uri.query 
    end

    response = Swagger::Request.new(:POST, path, {:params=>queryopts,:headers=>headers, :body=>post_body }).make.body
    OriginList.new(response)

  end

def self.origin (_X_Mashape_Key,firstname= "John",lastname= "Smith",opts={})
    query_param_keys = []

    # verify existence of params
    raise "_X_Mashape_Key is required" if _X_Mashape_Key.nil?
    raise "firstname is required" if firstname.nil?
    raise "lastname is required" if lastname.nil?
    # set default values and merge with input
    #HACK: use '' for key
    options = {
    :'X-Mashape-Key' => _X_Mashape_Key,
      :'firstname' => firstname,
      :'lastname' => lastname}.merge(opts)

    #resource path
    path = "/json/origin/{firstname}/{lastname}".sub('{format}','json').sub('{' + 'firstname' + '}', escapeString(firstname))
    .sub('{' + 'lastname' + '}', escapeString(lastname))
    

    
    # pull querystring keys from options
    queryopts = options.select do |key,value|
      query_param_keys.include? key
    end
  
    #HACK: use '' for key
    headers = {}
    headers[:'X-Mashape-Key'] = _X_Mashape_Key
    # http header
    headers['Accept'] = 'application/json'
    headers['Content-Type'] = 'application/x-www-form-urlencoded'
    
    post_body = nil
    #HACK: form parameter
    has_fields = false
    form_parameter_hash = {}
    if has_fields
      uri = Addressable::URI.new
      uri.query_values = form_parameter_hash
      post_body = uri.query 
    end

    response = Swagger::Request.new(:GET, path, {:params=>queryopts,:headers=>headers, :body=>post_body }).make.body
    Origin.new(response)

  end

end
end

