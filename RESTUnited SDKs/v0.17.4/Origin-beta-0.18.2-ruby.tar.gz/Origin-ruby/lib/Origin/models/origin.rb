module Origin
class Origin
  attr_accessor :country, :countryAlt, :countryFirstName, :countryLastName, :countryName, :region, :score, :scoreFirstName, :scoreLastName, :script, :subRegion, :topRegion

  # :internal => :external
  def self.attribute_map
    {
      :country => :'country',
      :countryAlt => :'countryAlt',
      :countryFirstName => :'countryFirstName',
      :countryLastName => :'countryLastName',
      :countryName => :'countryName',
      :region => :'region',
      :score => :'score',
      :scoreFirstName => :'scoreFirstName',
      :scoreLastName => :'scoreLastName',
      :script => :'script',
      :subRegion => :'subRegion',
      :topRegion => :'topRegion'

    }
  end

  def initialize(attributes = {})
    return if attributes.empty?

    # convert hash key from symbol to string
    attributes = attributes.inject({}){|memo,(k,v)| memo[k.to_s] = v; memo}
    
    # Morph attribute keys into undescored rubyish style
    if self.class.attribute_map[:"country"]
      @country = attributes["country"]
      end
    if self.class.attribute_map[:"countryAlt"]
      @countryAlt = attributes["countryAlt"]
      end
    if self.class.attribute_map[:"countryFirstName"]
      @countryFirstName = attributes["countryFirstName"]
      end
    if self.class.attribute_map[:"countryLastName"]
      @countryLastName = attributes["countryLastName"]
      end
    if self.class.attribute_map[:"countryName"]
      @countryName = attributes["countryName"]
      end
    if self.class.attribute_map[:"region"]
      @region = attributes["region"]
      end
    if self.class.attribute_map[:"score"]
      @score = attributes["score"]
      end
    if self.class.attribute_map[:"scoreFirstName"]
      @scoreFirstName = attributes["scoreFirstName"]
      end
    if self.class.attribute_map[:"scoreLastName"]
      @scoreLastName = attributes["scoreLastName"]
      end
    if self.class.attribute_map[:"script"]
      @script = attributes["script"]
      end
    if self.class.attribute_map[:"subRegion"]
      @subRegion = attributes["subRegion"]
      end
    if self.class.attribute_map[:"topRegion"]
      @topRegion = attributes["topRegion"]
      end
    

  end

  def to_body
    body = {}
    self.class.attribute_map.each_pair do |key, value|
      next if self.send(key).nil?

      if self.send(key).respond_to? :to_body
        body[value] = self.send(key).to_body
      elsif self.send(key).kind_of?(Array)
        body[value] = []
        self.send(key).each do |arr|
           if arr.respond_to? :to_body
               body[value] << arr.to_body
           else
               body[value] << arr
           end
        end
      else
        body[value] = self.send(key)
      end
      
    end
    body
  end
end
end

