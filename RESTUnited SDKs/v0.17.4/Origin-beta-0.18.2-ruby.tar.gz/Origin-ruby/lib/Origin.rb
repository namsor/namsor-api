# Create the base module
module Origin 

# Swagger common files
require 'Origin/monkey.rb'
require 'Origin/swagger.rb'
require 'Origin/swagger/configuration.rb'
require 'Origin/swagger/request.rb'
require 'Origin/swagger/response.rb'
require 'Origin/swagger/version.rb'


# Models
require 'Origin/models/originlist.rb'
require 'Origin/models/names.rb'
require 'Origin/models/origin.rb'
require 'Origin/models/nameslist.rb'


# APIs
require 'Origin/api/json_api.rb'


end
